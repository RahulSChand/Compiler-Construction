#include "inter_code.h"
//rahul chand
//2015A7PS0163P

void file_print(char* ,arith* ,symbol_table*);
